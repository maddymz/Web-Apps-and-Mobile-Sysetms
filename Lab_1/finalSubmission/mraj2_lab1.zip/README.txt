I have added a key value pair ("number": -2) in the JSON object
to match the reslt which is indicated in PARTC point 8 in the pdf.

To initialize the Calculator and PreCal with an intial value, i am passing 
the intial value to the constructor while creating a new object.


